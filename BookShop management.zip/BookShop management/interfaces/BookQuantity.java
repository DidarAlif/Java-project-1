package interfaces;
import java.lang.*;
 
 public interface BookQuantity
 {
	boolean addQuantity(int amount);
	boolean sellQuantity(int amount);
 }