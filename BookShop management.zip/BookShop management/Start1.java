import java.lang.*;
import java.util.Scanner;
import classes.*;
import fileio.*;
import java.io.*;


public class Start1
{
	public static void main(String args[]) throws Exception
	{
		Scanner sc =new Scanner(System.in);
		Publication p = new Publication();
		FileReadWriteDemo frwd =new FileReadWriteDemo();
		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader bfr = new BufferedReader(isr);
		
		
		System.out.println("----------------------------------------");
		System.out.println("Welcome to Famous Publicion");
		System.out.println("----------------------------------------");
		
        boolean repeat = true;
		
		while(repeat)
		{
			System.out.println( "------------------------------------------");
			System.out.println("What do you want to do?");
			System.out.println("\t1. Employee Management");
			System.out.println("\t2. BookShop Management");
			System.out.println("\t3. BookShop-Account Management");
			System.out.println("\t4. Book Quantity");
			System.out.println("\t5. Exit");
			
			System.out.print("Your Choice: ");
			int choice = sc.nextInt();
			
			
			switch(choice)
			{
				case 1:
				
				    System.out.println("-------------------------------------------");
					System.out.println("You have chose Employee Management");
					System.out.println("-------------------------------------------");
					
					System.out.println("You have the following options:");
					System.out.println("\t1. Insert New Employee");
					System.out.println("\t2. Remove Existing Employee");
					System.out.println("\t3. Search an Employee");
					System.out.println("\t4. Show All Employees");
					System.out.println("\t5. Go Back");
					
					System.out.print("Your option: ");
					int option1 = sc.nextInt();
					
					switch(option1)
					{
						
						case 1:
							
							System.out.println("-------------------------------------------");
							System.out.println("You have chose to Insert a New Employee");
							System.out.println("-------------------------------------------");
							
							System.out.print("Enter Employee Id: ");
							String empId1 = sc.next();
							System.out.print("Enter Employee Name: ");
							String name1 = bfr.readLine();
							System.out.print("Enter Employee Salary: ");
							double salary1 = sc.nextDouble();
							System.out.print("Enter Employee NID: ");
							int nid1 = sc.nextInt();
							
							Employee e1 = new Employee();
							e1.setEmpId(empId1);
							e1.setName(name1);
							e1.setSalary(salary1);
							e1.setNid(nid1);

							
							if(p.insertEmployee(e1))//b
							{
								System.out.println("Employee Inserted.. EmpId: "+ e1.getEmpId());
							}
							else
							{
								System.out.println("Employee Can Not be Inserted... EmpId: " + e1.getEmpId());
							}
							
							break;
							
						case 2:
						
							System.out.println("-------------------------------------------");
							System.out.println("You have chose to Remove an Existing Employee");
							System.out.println("-------------------------------------------");
							
							System.out.print("Enter Employee Id: ");
							String empId2 = sc.next();
							
							Employee e2 = p.searchEmployee(empId2);
							
							if(e2 != null)
							{
								if(p.removeEmployee(e2))
								{
									System.out.println("Employee Removed..... EmpId: " + e2.getEmpId());
								}
								else
								{
									System.out.println("Employee Not Removed..... EmpId: " + e2.getEmpId());
								}
							}
							else
							{
								System.out.println("Employee Not Found..... EmpId: " + empId2);
							}
							break;
							
						case 3:
						
							System.out.println("-------------------------------------------");
							System.out.println("You have chose to Search an Existing Employee");
							System.out.println("-------------------------------------------");
						
							System.out.print("Enter Employee Id: ");
							String empId3 = sc.next();
							
							Employee e3 = p.searchEmployee(empId3);
							
							if(e3 != null)
							{
								System.out.println("Employee Found.....");
								System.out.println("Employee Id: " + e3.getEmpId());
								System.out.println("Employee Name: " + e3.getName());
								System.out.println("Employee Salary: " + e3.getSalary());
								System.out.println("Employee NID: " + e3.getNid());
								System.out.println();
							}
							else
							{
								System.out.println("Employee Not Found..... EmpId: " + empId3);
							}
							break;
							
						case 4:
						
							System.out.println("-------------------------------------------");
							System.out.println("You have chose to See All Employees");
							System.out.println("-------------------------------------------");
							
							p.showAllEmployees();							
							break;
							
						case 5:
						
							System.out.println("-------------------------------------------");
							System.out.println("Going Back................");
							System.out.println("-------------------------------------------");
							break;
							
						default:
							
							System.out.println("-------------------------------------------");
							System.out.println("Invalid Option...............");
							System.out.println("-------------------------------------------");
							break;	
					}
					break;//b
					
				case 2:
				    
					System.out.println("-------------------------------------------");
					System.out.println("You have chose BookShop Management");
					System.out.println("-------------------------------------------");
					
					System.out.println("You have the following options:");
					System.out.println("\t1. Insert New BookShop");
					System.out.println("\t2. Remove Existing BookShop");
					System.out.println("\t3. Search a BookShop");
					System.out.println("\t4. Show All BookShops");
					System.out.println("\t5. Go Back");
					
					System.out.print("Your option: ");
					int option2 = sc.nextInt();
					
					switch(option2)
					{
						
						case 1:
							
							System.out.println("-------------------------------------------");
							System.out.println("You have chose to Insert a New BookShop");
							System.out.println("-------------------------------------------");
							
							System.out.print("Enter BookShop Id: ");
							String bsId1 = sc.next();
							System.out.print("Enter BookShop Name: ");
							String name1 = bfr.readLine();
							
							
							BookShop bs1 = new BookShop(bsId1, name1);
							
							
							if(p.insertBookShop(bs1))
									{
										System.out.print("BookShop Inserted Successfully.");
										System.out.println("Name "+ name1+ ",  Id  "+bsId1);
									}
									else
									{
										System.out.println("BookShop can not be created now. Try again later");
									}
							
							break;
						case 2:
						
							
							System.out.println("-------------------------------------------");
							System.out.println("You have chose to Remove an Existing BookShop");
							System.out.println("-------------------------------------------");
							
							System.out.print("Enter BookShop Id: ");
							String bsId2 = bfr.readLine();
							
							BookShop bs2 = p.searchBookShop(bsId2);
							
							
							System.out.println("Are You sure you want to delete this BookShop? ");
							System.out.print("Press 1 to delete BookShop ");

							int delete = sc.nextInt();

							if(delete==1){

								if(bs2 != null){
									if(p.removeBookShop(bs2)){
										System.out.println("BookShop ID " + bsId2+ " Removed Successfully.");
									}
									else{System.out.println("BookShop can not be removed now. Try again later");}
								}
								else{System.out.println("No BookShop found.");}
							}
							else{System.out.println("BookShop Account is not deleted. Thanks for come back");}
							
						
							break;
						
						case 3:	
						
							System.out.println("-------------------------------------------");
							System.out.println("You have chose to Search an Existing BookShop");
							System.out.println("-------------------------------------------");
						
							System.out.print("Enter BookShop Id: ");
							String bsId3 = sc.next();
							
							BookShop bs3 = p.searchBookShop(bsId3);
							
							if(bs3!= null)
							{
								System.out.println("Bookshop Found.....");
								System.out.println("BookShop Id: " + bs3.getBsId());
								System.out.println("BookShop Name: " + bs3.getName());
								System.out.println();
								
								bs3.showAllBooks();

							}
							else
							{
								System.out.println("Bookshop Not Found..... BSId: " + bsId3);
							}
							
							break;
							
						case 4:
						
							System.out.println("-------------------------------------------");
							System.out.println("You have chose to See All Bookshops");
							System.out.println("-------------------------------------------");
							
							p.showAllBookShops();							
							break;
							
						case 5:
						
							System.out.println("-------------------------------------------");
							System.out.println("Going Back To The main Menu");
							System.out.println("-------------------------------------------");
							break;
							
						default:
							
							System.out.println("-------------------------------------------");
							System.out.println("Invalid Option. Try again later..............");
							System.out.println("-------------------------------------------");
							break;	
					}
		
					
					break;
					
				case 3:
				    
					
					System.out.println("-------------------------------------------");
					System.out.println("You have chose BookShop-Account Management");
					System.out.println("-------------------------------------------");
					
					System.out.println("You have the following options: 'Choose 1'--");
					System.out.println("\t1. Insert New Book");
					System.out.println("\t2. Remove Existing Book");
					System.out.println("\t3. Show All Books");
					System.out.println("\t4. Search a Book");
					System.out.println("\t5. Go Back");
				
					System.out.print("Enter you option: ");
					int option3 = sc.nextInt();

					switch(option3)
					{
						
						case 1: 
						System.out.println("You have choose to Insert New Books");
						System.out.print("BookShop ID: ");
						String bsId3 = sc.next();

						if(p.searchBookShop(bsId3) != null){

							System.out.println("Which types of Book do you want to insert ?");
							System.out.println("\t1. StoryBook");
							System.out.println("\t2. TextBook");
							System.out.println("\t3. Go Back");
					
							System.out.print("Enter Book Type: ");//f
							int choice12 = sc.nextInt();

							switch(choice12){
							
							case 1: 
													
								
								System.out.print("Book Id : ");
								String isbn12 = sc.next();
								
								System.out.print("Book's Name: ");
								String bookTitle12 = sc.next();
								
								System.out.print("Book's Author Name: ");
								String authorName12 = sc.next();
								
								System.out.print("Book Price : ");
								double price12 = sc.nextDouble();

								System.out.print("Available Quantity : ");
								int availableQuantity12 = sc.nextInt();
				
								System.out.print("Book Category : ");
								String category12 = sc.next();

								Book List12 = new StoryBook(isbn12,bookTitle12,authorName12,price12,availableQuantity12 ,category12 );
								
								if(p.searchBookShop(bsId3).insertBook(List12))
								{
									System.out.println("Book Id Number "+ isbn12 +" inserted for "+ bsId3);
								}
								else
								{
									System.out.println("Book Can Not be inserted");
								}

								
								

							break;

						case 2 :

								System.out.print("Book Id : ");
								String isbn13 = sc.next();
								
								System.out.print("Book's Name: ");
								String bookTitle13 = sc.next();
								
								System.out.print("Book's Author Name: ");
								String authorName13 = sc.next();
								
								System.out.print("Book Price : ");
								double price13 = sc.nextDouble();

								System.out.print("Available Quantity : ");
								int availableQuantity13 = sc.nextInt();
				
								System.out.print("Book Standard : ");
								int standard13 = sc.nextInt();

								Book List13 = new TextBook(isbn13,bookTitle13,authorName13,price13,availableQuantity13 ,standard13 );
								
								if(p.searchBookShop(bsId3).insertBook(List13))
								{
									System.out.println("Book Id Number "+ isbn13 +" inserted for "+ bsId3);
								}
								else
								{
									System.out.println("Book Can Not be inserted");
								}

								
							break;

						case 3: 
								System.out.println("Going Back to the main menu...............");
												
										break;

										default: 

											System.out.println("Invalid option . Try again...............");
												break;
										}
									}

								else{System.out.println("Book Id does not match. Try again.");}

											
							break;
			
				case 2 :

						System.out.println("You have choose to Remove Books ");
						System.out.print("BookShop ID: ");
							String bookId199 = sc.next();

							if(p.searchBookShop(bookId199) != null){
							BookShop b199 = p.searchBookShop(bookId199);
							System.out.print("Book ID: ");
							String isbn66 = sc.next();

							Book bt55 = b199.searchBook(isbn66);

								if(bt55!= null){
									System.out.println("Are You sure you want to delete this Book? ");
									System.out.print("Press 1 to delete Book  ");

									int delete = sc.nextInt();

									if(delete==1){
										if(b199.removeBook(bt55))
										{
											System.out.print("Book  Removed Successfully.");
										}
										else{System.out.println("Book can not be removed now. Try again later");}
										}
								
									else{System.out.println("Account is not deleted. Thanks for come back");}
									}
								else{System.out.println("No Book  found.");}
							}
							else{System.out.println("No BookShop found.");}
							break;

				case 3: 
					System.out.println("You have chose to Show All Book");
					System.out.print("BookShop  ID: ");
					String bookId110 = sc.next();

					BookShop b100 = p.searchBookShop(bookId110);

					if(p.searchBookShop(bookId110)!=null){
					System.out.println("BookShop has been founded.");
					b100.showAllBooks();
														}
					else{System.out.println("No BookShop found.");}
														

					break;

				case 4 : 

					System.out.println("You have chose to Search Book");
					
					
					System.out.print("BookShop ID: ");
					String bId100 = sc.next();

					if(p.searchBookShop(bId100) != null){
					BookShop br44 = p.searchBookShop(bId100);
					System.out.print("Book ID: ");
					String isbn44 = sc.next();

					Book k47 = br44.searchBook(isbn44);

					if(k47!= null){
						System.out.println("BookShop has been founded.");
						
						br44.showAllBooks();
						
					}
					else{System.out.println("No BookShop found.");}
					}

					else{System.out.println("No BookShop found.");}

					break;
					
				case 5: 
								System.out.println("Going Back to the main menu...............");
								
								break;
		
				default :

								System.out.println("Invalid option . Try again...............");
								
								break;
					}
					break;
						
			case 4:
				    System.out.println("-------------------------------------------");
					System.out.println("You have chose BookQuantity");
					System.out.println("-------------------------------------------");
					
					System.out.println("You have the following options:");
					System.out.println("\t1. Add Book");
					System.out.println("\t2. Sell Book");
					System.out.println("\t3. Show Add Sell History");
					System.out.println("\t4. Go Back");
					
					System.out.print("Your option: ");
					int option4 = sc.nextInt();
					
					switch(option4)
					{
							
						case 1: 
							
							
							System.out.println("You have chose to Add Books");
							

							System.out.print("Enter BookShop ID: ");//f
							
							String bs11 = sc.next();

							if(p.searchBookShop(bs11) != null){

								System.out.print("Enter Book ID: ");
							
								String bookid149 = sc.next();

								if(p.searchBookShop(bs11).searchBook(bookid149) != null){

									System.out.print("Added Book Quantity : ");
									int amount1 = sc.nextInt();
									if(p.searchBookShop(bs11).searchBook(bookid149).addQuantity(amount1)){

									System.out.println("Book Amount Added ....");
									frwd.writeInFile("Amount : " +amount1 + "  added in "+ bookid149+ " by "+ bs11);
									}
									else{System.out.println("Can Not Added");}
								}
								else{System.out.println("Invalid Book Id Number");}

							}
							else{System.out.println("BookShop ID does not MISMATCH");}
							


							break;

						case 2 : 
							System.out.println("You have chose to Sell Book");
							System.out.print("Enter BookShop ID: ");
							
							String bs22= sc.next();

							if(p.searchBookShop(bs22) != null){

								System.out.print("Enter Book ID: ");
							
								String bookid52 = sc.next();

								if(p.searchBookShop(bs22).searchBook(bookid52) != null){

									System.out.print("Selled Book Quantity : ");
									int amount10 = sc.nextInt();
									if(p.searchBookShop(bs22).searchBook(bookid52).sellQuantity(amount10)){

									System.out.println("Book  Selled ....");
									frwd.writeInFile("Amount : " +amount10 + "Selled in "+ bookid52+ " by "+ bs22);
									}
									else{System.out.println("Can Not Selled");}
								}
								else{System.out.println("Invalid Book Id Number");}

							}
							else{System.out.println("BookShop ID  does not MISMATCH");}

							break;
						case 3: 
							System.out.println("You have chose to Show ADD SELL History");
							frwd.readFromFile();
							break;

						case 4 :
								
								
								System.out.println("Going Back to the main menu...............");
							
								

							break;

						default :

								
								
								System.out.println("Invalid option . Try again...............");
								
								


							break;
						}			

					break;
				

				case 5:
					System.out.println("-------------------------------------------");
					System.out.println("You have chose to Exit");
					System.out.println("-------------------------------------------");
					
					repeat = false;
				
					break;
					
				default:
					System.out.println("-------------------------------------------");
					System.out.println("Invalid Choice...............");
					System.out.println("-------------------------------------------");//f
					break;
				
				}
			}
		}
	}
